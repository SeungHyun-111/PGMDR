import { useState } from 'react'
import useScheduleStore from '../../store/useScheduleStore'
import ProductTooltip from './ProductTooltip'

export default function ProductCard({ item, perfMap, index }) {
  const [hover, setHover] = useState(false)
  const { starred, toggleStarred } = useScheduleStore()
  const isStarred = !!starred[item.itemId]
  const lastPerf = perfMap[item.perfKey] || null
  const isNew = !!item.newProductType

  const handleDragStart = (e) => {
    e.dataTransfer.setData('itemId', item.itemId)
    e.dataTransfer.effectAllowed = 'move'
  }

  return (
    <div
      className={`product-card ${isNew ? 'is-new' : ''}`}
      draggable
      onDragStart={handleDragStart}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      <div className="product-card-top">
        <button
          className={`star-btn ${isStarred ? 'active' : ''}`}
          onClick={(e) => {
            e.stopPropagation()
            toggleStarred(item.itemId)
          }}
        >
          {isStarred ? '★' : '☆'}
        </button>

        <div className="product-title">
          {item.pgmCodeName}
        </div>
      </div>

      <div className="product-meta">
        <span>{item.mdCategory || '-'}</span>
        <span>{item.team || '-'}</span>
        <span>{item.dealTypeConverted || item.dealType || '-'}</span>
      </div>

      <div className="product-sub">
        {item.brand && <span>{item.brand}</span>}
        {item.newProductType && <span className="badge new">{item.newProductType}</span>}
      </div>

      <div className="product-perf">
        <span>취급/분</span>
        <strong>{lastPerf ? Number(lastPerf.salesPerWeightedMin || 0).toLocaleString() : '-'}</strong>
        <span>한익/분</span>
        <strong>{lastPerf ? Number(lastPerf.profitPerWeightedMin || 0).toLocaleString() : '-'}</strong>
      </div>

      {hover && (
        <ProductTooltip item={item} perfMap={perfMap} />
      )}
    </div>
  )
}