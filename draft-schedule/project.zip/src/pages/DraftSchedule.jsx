import { useEffect, useState } from 'react'
import useScheduleStore from '../store/useScheduleStore'
import ScheduleGrid from '../components/schedule/ScheduleGrid'
import Sidebar from '../components/sidebar/Sidebar'
import SetupModal from '../components/modal/SetupModal'
import { splitWeightedMin } from '../utils/weightedMin'
import { makePerfKey } from '../hooks/usePerformanceMap'

export default function DraftSchedule({ setupPopup, setSetupPopup }) {
  const {
    isLoaded, isLoading, error,
    scheduleBlocks, perfMap,
    loadInitData, loadStarred, saveBlock, scheduleItem,
  } = useScheduleStore()

  const [sidebarOpen, setSidebarOpen] = useState(true)

  useEffect(() => {
    loadStarred()
    const lastKey = localStorage.getItem('lastWeekKey')
    if (lastKey && !isLoaded) {
      const [date, pool] = lastKey.split('_')
      loadInitData(date, pool)
    }
  }, [])

  const handleSetupComplete = async (startDate, poolType) => {
    await loadInitData(startDate, poolType)
    setSetupPopup(false)
  }

  const handleBlockDrop = async (slot, channel, itemId, isSplit) => {
    const { proposalItems } = useScheduleStore.getState()
    const item = proposalItems.find(p => p.itemId === itemId)
    if (!item) return

    const blockKey = isSplit ? `${slot.slotId}_${channel}` : slot.slotId
    const existingBlock = scheduleBlocks[blockKey]

    let weightedMin = slot.weightedMin
    if (isSplit) {
      const { caWeighted, ipWeighted } = splitWeightedMin(slot.weightedMin, slot.dateKey, slot.timeText)
      weightedMin = channel === 'CA' ? caWeighted : ipWeighted
    }

    const dealType = item.dealTypeConverted || item.dealType || ''
    const perfKey  = item.perfKey || makePerfKey(dealType, item.pgmCodeName) || null

    if (existingBlock && !existingBlock.isDefault) {
      const brand1 = (existingBlock.pgmCodeName || '').replace(/^\[(.+?)\].*/, '$1')
      const brand2 = (item.pgmCodeName || '').replace(/^\[(.+?)\].*/, '$1')
      await saveBlock(blockKey, {
        slotId: slot.slotId, blockKey,
        dateKey: slot.dateKey, timeText: slot.timeText,
        durationMin: slot.durationMin, weightedMin: slot.weightedMin,
        channel, isCompeting: true,
        pgmCodeName: `[${brand1}*${brand2}]`,
        item1: {
          itemId: existingBlock.itemId, pgmCodeName: existingBlock.pgmCodeName,
          mdTeam: existingBlock.mdTeam, orgName: existingBlock.orgName,
          dealType: existingBlock.dealType, perfKey: existingBlock.perfKey || null,
          weightedMin: existingBlock.weightedMin,
        },
        item2: {
          itemId: item.itemId, pgmCodeName: item.pgmCodeName,
          mdTeam: item.mdTeam, orgName: item.mdTeam,
          dealType, perfKey, weightedMin,
        },
        isDefault: false, assignedAt: Date.now(),
      })
      await scheduleItem(itemId)
      return
    }

    await saveBlock(blockKey, {
      slotId: slot.slotId, blockKey,
      dateKey: slot.dateKey, timeText: slot.timeText,
      durationMin: slot.durationMin, weightedMin,
      channel,
      itemId: item.itemId,
      pgmCodeName: item.pgmCodeName,
      pgmCode: item.pgmCode,
      mdTeam: item.mdTeam,
      orgName: item.mdTeam,
      dealType, perfKey,
      isDefault: false, assignedAt: Date.now(),
    })
    await scheduleItem(itemId)
  }

  if (isLoading) return <LoadingScreen />

  if (error) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
      <div style={{ color: 'var(--red)', fontSize: 14 }}>오류: {error}</div>
    </div>
  )

  if (setupPopup || !isLoaded) {
    return (
      <SetupModal
        isLoading={isLoading}
        error={error}
        onClose={() => setSetupPopup(false)}
        onSubmit={handleSetupComplete}
      />
    )
  }

  return (
    <div style={{ display: 'flex', height: '100%', overflow: 'hidden' }}>
      <div style={{ flex: 1, minWidth: 0, overflow: 'hidden' }}>
        <ScheduleGrid onBlockDrop={handleBlockDrop} />
      </div>
      <Sidebar isOpen={sidebarOpen} onToggle={() => setSidebarOpen(v => !v)} />
    </div>
  )
}

function LoadingScreen() {
  const steps = ['PGM 슬롯', '제안상품', '실적 DB', '선편성 정보', '목표 데이터']
  const [step, setStep] = useState(0)
  useEffect(() => {
    const t = setInterval(() => setStep(v => Math.min(v + 1, steps.length - 1)), 1800)
    return () => clearInterval(t)
  }, [])
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', flexDirection: 'column', gap: 16 }}>
      <div style={{ width: 40, height: 40, borderRadius: '50%', border: '3px solid var(--border)', borderTop: '3px solid var(--accent)', animation: 'spin .8s linear infinite' }} />
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      <div style={{ fontSize: 13, color: 'var(--text2)' }}>{steps[step]} 불러오는 중...</div>
      <div style={{ fontSize: 11, color: 'var(--text3)' }}>최초 로딩 시 30~60초 소요됩니다</div>
    </div>
  )
}