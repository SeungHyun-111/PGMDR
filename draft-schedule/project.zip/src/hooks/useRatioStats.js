import { useMemo } from 'react'

export default function useRatioStats(scheduleBlocks, categoryMap, viewType) {
  return useMemo(() => {
    const group = {}
    let totalWeighted = 0
    let competingWeighted = 0
    const channel = { CA: 0, IP: 0, ALL: 0, 경쟁: 0 }

    Object.values(scheduleBlocks).forEach(block => {
      if (!block || block.isDefault) return
      const w = block.weightedMin || 0
      totalWeighted += w

      const ch = block.channel || 'ALL'
      if (block.isCompeting) {
        channel['경쟁'] = (channel['경쟁'] || 0) + w
        competingWeighted += w
      } else {
        channel[ch] = (channel[ch] || 0) + w
      }

      const key = viewType === 'category'
        ? (block.mdCategory || categoryMap[block.pgmCodeName] || '미분류')
        : (block.isCompeting ? '경쟁' : (block.mdTeam || block.orgName || '미지정'))

      group[key] = (group[key] || 0) + w
    })

    return { group, channel, totalWeighted, competingWeighted }
  }, [scheduleBlocks, categoryMap, viewType])
}