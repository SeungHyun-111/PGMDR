// src/components/common/PresenceBar.jsx
import { useState, useEffect } from 'react'
import { db, ref, onValue, off } from '../../api/firebase'
import useScheduleStore from '../../store/useScheduleStore'

const COLORS = ['#4a6cf7','#16a34a','#d97706','#dc2626','#7c3aed','#0891b2','#be185d']

function getColor(name) {
  let hash = 0
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash)
  return COLORS[Math.abs(hash) % COLORS.length]
}

export default function PresenceBar() {
  const { startDate, poolType, userName } = useScheduleStore()
  const [users, setUsers] = useState([])

  useEffect(() => {
    if (!startDate) return
    const weekKey = `${startDate}_${poolType}`
    const r = ref(db, `presence/${weekKey}`)
    let latest = {}

    const filter = () => {
      const now = Date.now()
      return Object.values(latest)
        .filter(u => u && now - u.ts < 90000)
        .reduce((acc, u) => {
          if (!acc.find(x => x.userName === u.userName)) acc.push(u)
          return acc
        }, [])
        .sort((a, b) => (a.ts || 0) - (b.ts || 0))
    }

    onValue(r, snap => {
      latest = snap.exists() ? snap.val() : {}
      setUsers(filter())
    })

    // 혼자 접속 중일 때 onValue 트리거 없이도 stale 항목 정리
    const tick = setInterval(() => setUsers(filter()), 15000)

    return () => { off(r); clearInterval(tick) }
  }, [startDate, poolType])

  if (users.length === 0) return null

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
      {users.map((u, i) => (
        <div
          key={i}
          title={u.userName}
          style={{
            minWidth: 26,
            maxWidth: 42,
            height: 24,
            padding: '0 6px',
            borderRadius: 999,
            background: getColor(u.userName),
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 10,
            fontWeight: 800,
            color: '#fff',
            border: u.userName === userName ? '2px solid var(--accent)' : '2px solid var(--bg2)',
            cursor: 'default',
            flexShrink: 0,
            boxSizing: 'border-box',
            lineHeight: 1,
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'clip',
          }}
        >
          {(u.userName || '?').slice(0, 3)}
        </div>
      ))}
      <span style={{ fontSize: 10, color: 'var(--text3)', marginLeft: 2 }}>
        {users.length}명 접속 중
      </span>
    </div>
  )
}
